# DataAI ETL for Oracle AIDP Spark - Customer-Ready Evaluation

DataAI ETL is proprietary, source-available evaluation software from Yanbor
LLC, provider of the DataAI product, built with open-source technologies
including Apache Spark.

Start with `docs/INSTALLATION_AND_USAGE.md`, then run the packaged smoke test.
The package includes the DataAI artifacts required for this integration and
their SHA-256 manifest. External platform runtimes and vendor drivers listed in
the guide are intentionally not bundled.

Source assembly: Oracle customer evaluation archive.

Evaluation use is governed by `LICENSE.md`. Production, continued use, and
redistribution require written commercial authorization from Yanbor LLC.
DataAI software is provided AS IS and without obligations except those
expressly accepted in a signed agreement.
