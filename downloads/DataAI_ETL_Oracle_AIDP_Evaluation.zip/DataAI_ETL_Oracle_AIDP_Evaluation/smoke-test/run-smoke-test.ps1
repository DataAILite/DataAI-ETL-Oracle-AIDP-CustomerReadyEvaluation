[CmdletBinding()]
param(
    [string]$SparkSubmit = 'spark-submit.cmd'
)

$ErrorActionPreference = 'Stop'
$packageRoot = Split-Path -Parent $PSScriptRoot
$version = '0.1.0-SNAPSHOT'
$applicationJar = Join-Path $PSScriptRoot "dataai-customer-ready-smoke-test-$version.jar"
$dataAiJars = @(
    (Join-Path $packageRoot "lib\dataai-spark-api-$version.jar"),
    (Join-Path $packageRoot "lib\dataai-spark-quality-$version.jar"),
    (Join-Path $packageRoot "lib\dataai-spark-core-$version.jar"),
    (Join-Path $packageRoot "lib\dataai-spark-functions-$version.jar")
)
$tableauJar = Join-Path $packageRoot "lib\dataai-spark-tableau-$version.jar"
$mainClass = 'com.dataai.customer.ready.DataAiCustomerReadySmokeTest'
$successMarker = 'DATAAI_CUSTOMER_READY_SMOKE_TEST_PASS'
if (Test-Path -LiteralPath $tableauJar -PathType Leaf) {
    $dataAiJars += $tableauJar
    $mainClass = 'com.dataai.customer.ready.TableauCustomerReadySmokeTest'
    $successMarker = 'DATAAI_TABLEAU_SMOKE_TEST_PASS'
}

foreach ($path in @($applicationJar) + $dataAiJars) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "Required smoke-test JAR was not found: $path"
    }
}

$sparkCommand = Get-Command -Name $SparkSubmit -ErrorAction Stop
$sparkExecutable = if ($sparkCommand.Source) { $sparkCommand.Source } else { $sparkCommand.Path }
$output = & $sparkExecutable `
    --master 'local[2]' `
    --conf 'spark.ui.enabled=false' `
    --conf 'spark.sql.shuffle.partitions=2' `
    --jars ($dataAiJars -join ',') `
    --class $mainClass `
    $applicationJar 2>&1
$exitCode = $LASTEXITCODE
$output | ForEach-Object { Write-Host $_ }
if ($exitCode -ne 0) {
    throw "DataAI evaluation smoke test failed with exit code $exitCode."
}
if (-not (($output | Out-String) -match [regex]::Escape($successMarker))) {
    throw "DataAI evaluation smoke test did not emit $successMarker."
}

Write-Host 'DataAI customer-ready evaluation smoke test completed successfully.'
